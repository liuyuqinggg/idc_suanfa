// ����������ֵ����

#include <iostream>

using namespace std;

int main()
{
	cout << "15   / 2   = " << 15   / 2   << '\n';
	cout << "15.0 / 2.0 = " << 15.0 / 2.0 << '\n';
	cout << "15.0 / 2   = " << 15.0 / 2   << '\n';
	cout << "15   / 2.0 = " << 15   / 2.0 << '\n';
}
