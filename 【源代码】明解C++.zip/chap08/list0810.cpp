// �޸��ַ���ָ��

#include <iostream>

using namespace std;

int main()
{
	char* p = "ABC";

	cout << "p = \"" << p << "\"\n";

	p = "XYZ";			// OK

	cout << "p = \"" << p << "\"\n";
}
