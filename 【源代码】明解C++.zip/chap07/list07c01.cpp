// ��ʾint�͵Ĵ�С��int*�͵Ĵ�С

#include <iostream>

using namespace std;

int main()
{
	cout << "sizeof(int)  = " << sizeof(int)  << '\n';
	cout << "sizeof(int*) = " << sizeof(int*) << '\n';
}
